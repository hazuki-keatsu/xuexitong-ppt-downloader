chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'GM_xmlhttpRequest') {
    fetch(request.details.url, {
      method: request.details.method || 'GET',
      headers: request.details.headers
    })
      .then(async response => {
        const contentType = response.headers.get('content-type');
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
          sendResponse({
            status: response.status,
            statusText: response.statusText,
            response: reader.result, // data:url base64
            contentType: contentType
          });
        };
        reader.readAsDataURL(blob);
      })
      .catch(error => {
        sendResponse({
          error: error.message
        });
      });
    return true; // Keep channel open for async response
  }
});